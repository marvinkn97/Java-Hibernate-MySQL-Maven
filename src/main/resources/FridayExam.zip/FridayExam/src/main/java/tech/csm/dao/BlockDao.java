package tech.csm.dao;

import tech.csm.entity.Block;

import java.util.List;

public interface BlockDao {
    List<Block> getAllBlocks();
}
