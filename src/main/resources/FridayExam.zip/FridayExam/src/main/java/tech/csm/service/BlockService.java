package tech.csm.service;

import tech.csm.entity.Block;

import java.util.List;

public interface BlockService {
    List<Block> getAllBlocks();
}
